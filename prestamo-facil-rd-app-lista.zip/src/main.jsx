import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const STORAGE_KEY = "prestamo_facil_rd_v3";
const todayISO = () => new Date().toISOString().slice(0, 10);
const money = (n) => new Intl.NumberFormat("es-DO", { style: "currency", currency: "DOP", minimumFractionDigits: 2 }).format(Number(n || 0));
const cleanPhone = (tel) => String(tel || "").replace(/\D/g, "");

function App() {
  const [clients, setClients] = useState([]);
  const [query, setQuery] = useState("");
  const [showConfig, setShowConfig] = useState(false);
  const [config, setConfig] = useState({
    businessName: "Préstamo Fácil RD",
    profit: "60",
    lateFee: "100",
    defaultInstallments: "15",
    message: "Hola {cliente}, le recordamos que su cuota semanal es de {cuota}. Balance pendiente: {pendiente}. Gracias.",
  });
  const [form, setForm] = useState({ name: "", phone: "", idNumber: "", amount: "", installments: "15", profit: "60", lateFee: "100", startDate: todayISO(), note: "" });

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setClients(data.clients || []);
        setConfig((old) => ({ ...old, ...(data.config || {}) }));
      } catch {}
    }
  }, []);
  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify({ clients, config })); }, [clients, config]);

  function status(client) {
    const paidCount = client.schedule.filter((q) => q.paid).length;
    const lateFees = client.schedule.filter((q) => q.lateFeeApplied).length * client.lateFee;
    const paid = paidCount * client.weeklyPayment;
    const pending = Math.max(client.total + lateFees - paid, 0);
    const lateCount = client.schedule.filter((q) => !q.paid && q.date < todayISO()).length;
    const next = client.schedule.find((q) => !q.paid);
    return { paidCount, lateFees, paid, pending, lateCount, next };
  }

  function createLoan() {
    const amount = Number(form.amount);
    const installments = Number(form.installments || config.defaultInstallments);
    const profit = Number(form.profit || config.profit);
    const lateFee = Number(form.lateFee || config.lateFee);
    if (!form.name.trim() || !form.phone.trim() || !amount || !installments) { alert("Completa nombre, teléfono, monto y cuotas."); return; }
    const total = amount * (1 + profit / 100);
    const weeklyPayment = total / installments;
    const baseDate = new Date(form.startDate || todayISO());
    const schedule = Array.from({ length: installments }, (_, i) => {
      const d = new Date(baseDate); d.setDate(baseDate.getDate() + 7 * (i + 1));
      return { number: i + 1, date: d.toISOString().slice(0, 10), paid: false, paidDate: "", lateFeeApplied: false };
    });
    const client = { id: Date.now(), name: form.name.trim(), phone: form.phone.trim(), idNumber: form.idNumber.trim(), amount, installments, profit, lateFee, startDate: form.startDate, note: form.note, total, weeklyPayment, schedule, createdAt: new Date().toISOString() };
    setClients([client, ...clients]);
    setForm({ name: "", phone: "", idNumber: "", amount: "", installments: config.defaultInstallments, profit: config.profit, lateFee: config.lateFee, startDate: todayISO(), note: "" });
  }

  function togglePaid(clientId, installmentNumber) { setClients((prev) => prev.map((c) => c.id === clientId ? { ...c, schedule: c.schedule.map((q) => q.number === installmentNumber ? { ...q, paid: !q.paid, paidDate: !q.paid ? todayISO() : "" } : q) } : c)); }
  function toggleLateFee(clientId, installmentNumber) { setClients((prev) => prev.map((c) => c.id === clientId ? { ...c, schedule: c.schedule.map((q) => q.number === installmentNumber ? { ...q, lateFeeApplied: !q.lateFeeApplied } : q) } : c)); }
  function deleteClient(id) { if (confirm("¿Seguro que deseas eliminar este préstamo?")) setClients(clients.filter((c) => c.id !== id)); }
  function resetAll() { if (confirm("Esto borrará todos los préstamos guardados en este dispositivo. ¿Seguro?")) { setClients([]); localStorage.removeItem(STORAGE_KEY); } }
  function whatsappMessage(client) { const s = status(client); return config.message.replaceAll("{cliente}", client.name).replaceAll("{cuota}", money(client.weeklyPayment)).replaceAll("{pendiente}", money(s.pending)).replaceAll("{negocio}", config.businessName); }
  function openWhatsApp(client) { let tel = cleanPhone(client.phone); if (tel.length === 10 && !tel.startsWith("1")) tel = "1" + tel; window.open(`https://wa.me/${tel}?text=${encodeURIComponent(whatsappMessage(client))}`, "_blank"); }
  function exportCSV() {
    const rows = [["Cliente", "Telefono", "Cedula", "Monto", "Total", "Pago semanal", "Pagado", "Pendiente", "Atrasadas", "Fecha inicio"]];
    clients.forEach((c) => { const s = status(c); rows.push([c.name, c.phone, c.idNumber, c.amount, c.total, c.weeklyPayment, s.paid, s.pending, s.lateCount, c.startDate]); });
    const csv = rows.map((r) => r.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "prestamos_facil_rd.csv"; a.click(); URL.revokeObjectURL(url);
  }

  const summary = useMemo(() => clients.reduce((acc, c) => { const s = status(c); acc.clients += 1; acc.lent += c.amount; acc.toCollect += c.total + s.lateFees; acc.paid += s.paid; acc.pending += s.pending; acc.profit += c.total - c.amount + s.lateFees; acc.lateClients += s.lateCount > 0 ? 1 : 0; return acc; }, { clients: 0, lent: 0, toCollect: 0, paid: 0, pending: 0, profit: 0, lateClients: 0 }), [clients]);
  const filtered = clients.filter((c) => c.name.toLowerCase().includes(query.toLowerCase()) || c.phone.includes(query) || c.idNumber.includes(query));

  return <main>
    <section className="hero"><div><h1>{config.businessName}</h1><p>Sistema móvil para préstamos, cuotas semanales, mora y cobros por WhatsApp.</p></div><div className="hero-actions"><button onClick={() => setShowConfig(!showConfig)}>⚙️ Configurar</button><button onClick={exportCSV}>⬇️ Exportar</button></div></section>
    {showConfig && <section className="card"><h2>Configuración</h2><div className="grid"><label>Nombre del negocio<input value={config.businessName} onChange={(e) => setConfig({ ...config, businessName: e.target.value })} /></label><label>% ganancia<input type="number" value={config.profit} onChange={(e) => setConfig({ ...config, profit: e.target.value })} /></label><label>Mora RD$<input type="number" value={config.lateFee} onChange={(e) => setConfig({ ...config, lateFee: e.target.value })} /></label><label>Cuotas por defecto<input type="number" value={config.defaultInstallments} onChange={(e) => setConfig({ ...config, defaultInstallments: e.target.value })} /></label></div><label>Mensaje WhatsApp<textarea value={config.message} onChange={(e) => setConfig({ ...config, message: e.target.value })} /></label><small>Variables: {'{cliente}'}, {'{cuota}'}, {'{pendiente}'}, {'{negocio}'}</small><button className="danger" onClick={resetAll}>Borrar todo</button></section>}
    <section className="stats"><div><span>Clientes</span><b>{summary.clients}</b></div><div><span>Prestado</span><b>{money(summary.lent)}</b></div><div><span>A cobrar</span><b>{money(summary.toCollect)}</b></div><div><span>Pagado</span><b>{money(summary.paid)}</b></div><div><span>Pendiente</span><b>{money(summary.pending)}</b></div><div><span>Atrasados</span><b>{summary.lateClients}</b></div></section>
    <section className="card"><h2>Nuevo préstamo</h2><div className="grid"><label>Nombre<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Juan Pérez" /></label><label>Teléfono<input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="8091234567" /></label><label>Cédula opcional<input value={form.idNumber} onChange={(e) => setForm({ ...form, idNumber: e.target.value })} placeholder="000-0000000-0" /></label><label>Monto prestado<input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="10000" /></label><label>Cuotas<input type="number" value={form.installments} onChange={(e) => setForm({ ...form, installments: e.target.value })} /></label><label>Fecha inicio<input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} /></label><label>% ganancia<input type="number" value={form.profit} onChange={(e) => setForm({ ...form, profit: e.target.value })} /></label><label>Mora RD$<input type="number" value={form.lateFee} onChange={(e) => setForm({ ...form, lateFee: e.target.value })} /></label></div><div className="preview"><div><span>Total a cobrar</span><b>{money(Number(form.amount || 0) * (1 + Number(form.profit || 0) / 100))}</b></div><div><span>Pago semanal</span><b>{money((Number(form.amount || 0) * (1 + Number(form.profit || 0) / 100)) / Number(form.installments || 1))}</b></div></div><label>Nota opcional<input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="Dirección, garantía o referencia" /></label><button className="primary" onClick={createLoan}>➕ Guardar préstamo</button></section>
    <input className="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="🔎 Buscar por nombre, teléfono o cédula" />
    <section className="clients">{filtered.map((client) => { const s = status(client); return <article className="loan" key={client.id}><div className="loan-head"><div><h3>{client.name}</h3><p>📞 {client.phone}</p>{client.idNumber && <p>Cédula: {client.idNumber}</p>}{client.note && <p>Nota: {client.note}</p>}</div><div className="actions"><span className={s.lateCount > 0 ? "badge bad" : "badge ok"}>{s.lateCount > 0 ? `${s.lateCount} atrasada(s)` : "Al día"}</span>{s.pending === 0 && <span className="badge ok">Saldado</span>}<button onClick={() => openWhatsApp(client)}>WhatsApp</button><button className="danger-light" onClick={() => deleteClient(client.id)}>Eliminar</button></div></div><div className="mini-stats"><div><span>Monto</span><b>{money(client.amount)}</b></div><div><span>Total</span><b>{money(client.total)}</b></div><div><span>Semanal</span><b>{money(client.weeklyPayment)}</b></div><div><span>Pagado</span><b>{money(s.paid)}</b></div><div><span>Moras</span><b>{money(s.lateFees)}</b></div><div><span>Pendiente</span><b>{money(s.pending)}</b></div></div>{s.next && <p className="next">📅 Próxima cuota #{s.next.number}: {s.next.date}</p>}<div className="schedule">{client.schedule.map((q) => { const late = !q.paid && q.date < todayISO(); return <div className="installment" key={q.number}><div><b>Cuota {q.number}</b><small>Vence: {q.date}</small>{q.paid && <small className="green">Pagó: {q.paidDate}</small>}{q.lateFeeApplied && <small className="red">Mora aplicada</small>}{late && !q.lateFeeApplied && <small className="red">Atrasada sin mora</small>}</div><div><button className={q.paid ? "paid" : ""} onClick={() => togglePaid(client.id, q.number)}>✅</button><button className={q.lateFeeApplied ? "late" : ""} onClick={() => toggleLateFee(client.id, q.number)}>⚠️</button></div></div>; })}</div></article>; })}{clients.length === 0 && <div className="empty">Todavía no tienes préstamos registrados.</div>}</section>
  </main>;
}

createRoot(document.getElementById("root")).render(<App />);
