# Préstamo Fácil RD

App web móvil para controlar préstamos, cuotas semanales, ganancia, mora, pagos y cobros por WhatsApp.

## Publicar en Vercel

1. Crea cuenta en GitHub.
2. Crea un repositorio nuevo.
3. Sube todos estos archivos.
4. Entra a Vercel.
5. New Project > Importa el repositorio.
6. Framework: Vite.
7. Build command: npm run build.
8. Output directory: dist.
9. Deploy.

## Usar en el celular

1. Abre el link de Vercel en Chrome.
2. Toca los tres puntos.
3. Agregar a pantalla de inicio.
4. La app queda como icono.

## Nota

Esta versión guarda los datos en el dispositivo/navegador usando localStorage. Para una app comercial con usuarios, contraseña y datos en la nube, hay que conectar base de datos como Supabase/Firebase.
